#include "control.h"
#include "statemachine.h"

QueueHandle_t receive_q;
TimerHandle_t controltimer;

void CONTROL_Initialize ( void )
{
    receive_q = xQueueCreate(128, sizeof(struct JsonResponse));
    controltimer = xTimerCreate("ControlTimer", 200, pdTRUE, (void*)0, requeststatus);
    DRV_ADC_Open();
    DRV_ADC_Start();
    BaseType_t ret = xTimerStart(controltimer, (TickType_t) 5);
    if(!receive_q)
    {
        //DBG: TODO;
    }
    Pause();
}

void CONTROL_Tasks ( void )
{   
    
//    Left_Motor_PID(FORWARD, 5);
//    Right_Motor_PID(FORWARD, 25);
    static struct StateMachineParams smp = {false, false, false, false, false, false, false, 0};
    //vTaskDelay((TickType_t) 1000);
    
        struct JsonResponse js;
        BaseType_t ret = xQueueReceive(receive_q, &js, (TickType_t) 2);
        while(1)
        {
            ret = xQueueReceive(receive_q, &js, (TickType_t) 2);
            if (js.tsk == 63 && js.arg0 == 11)
            {
                break;
            }
        }
        Backward(35);
        while(1)
        {
            ret = xQueueReceive(receive_q, &js, (TickType_t) 2);
            if (js.tsk == 72 && js.arg0 == 1)
            {
                Pause();
                break;
            }
        }
        struct JsonRequest jsr = {0, 's', 0, 79, 0, -1, 0, 1, 7};
        SendOverWiFi(jsr);  
            
    
        while(1);
}



void SendToControlQueue(struct JsonResponse js)
{
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;
    BaseType_t ret = xQueueSendFromISR(receive_q, &js, &xHigherPriorityTaskWoken);
    if(ret==pdFALSE)
    {
        //sendToUART('f');
    }
    portEND_SWITCHING_ISR(xHigherPriorityTaskWoken);
}
